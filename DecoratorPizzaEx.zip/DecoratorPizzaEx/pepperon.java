public class pepperon implements basepizza{
    basepizza basepizza;
    public pepperon ( basepizza basepizza)
    {
        this.basepizza=basepizza;
    }

    public int cost()
    {
        return basepizza.cost()+100;
    }
}
