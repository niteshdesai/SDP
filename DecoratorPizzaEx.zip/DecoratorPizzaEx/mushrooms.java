public class mushrooms implements basepizza {
    basepizza basepizza;
    public mushrooms( basepizza basepizza)
    {
        this.basepizza=basepizza;
    }

    public int cost()
    {
        return basepizza.cost()+50;
    }
}
