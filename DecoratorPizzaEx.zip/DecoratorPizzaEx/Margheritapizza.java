public class Margheritapizza implements basepizza {
    public int cost()
    {
        return 200;
    }
}
