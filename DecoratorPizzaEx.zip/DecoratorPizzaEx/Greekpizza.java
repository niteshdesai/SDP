public class Greekpizza implements basepizza{
    
    public int cost()
    {
        return 100;
    }
}
