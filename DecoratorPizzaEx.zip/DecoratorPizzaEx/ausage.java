public class ausage implements basepizza{
    basepizza basepizza;
    public ausage( basepizza basepizza)
    {
        this.basepizza=basepizza;
    }

    public int cost()
    {
        return basepizza.cost()+150;
    }
}
