public interface basepizza {
    public int cost();
}
