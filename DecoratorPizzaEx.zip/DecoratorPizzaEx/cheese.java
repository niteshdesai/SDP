public class cheese implements basepizza{
    basepizza basepizza;
    public cheese( basepizza basepizza)
    {
        this.basepizza=basepizza;
    }

    public int cost()
    {
        return basepizza.cost()+120;
    }
}
