public class Main {
    public static void main(String[] args) {
        
        basepizza basepizza;

        basepizza=new Greekpizza();

        basepizza =new pepperon(basepizza);

        basepizza=new cheese(basepizza);

        basepizza=new mushrooms(basepizza);

        basepizza =new pepperon(basepizza);

        basepizza=new cheese(basepizza);

        basepizza=new mushrooms(basepizza);
        
     
        System.out.println(basepizza.cost());

    }
}
