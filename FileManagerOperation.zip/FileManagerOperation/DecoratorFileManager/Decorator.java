package DecoratorFileManager;
import CommonFileManager.iFileManager;
public abstract class Decorator implements iFileManager{
    iFileManager fm=null;
    Decorator(iFileManager fm)
    {
        this.fm=fm;
    }

}
