package DecoratorFileManager;

import CommonFileManager.iFileManager;

public class DecoratorComponet extends Decorator {
  
    String rolename;
   public DecoratorComponet(iFileManager fm,String role) {
        super(fm);
        this.rolename=role;
    }

    public void createFile() {
        if (rolename.equalsIgnoreCase("admin"))
            fm.createFile();
        else
            System.out.println("Access Denied , only access by admin");
    }


    public void createFolder() {
        if (rolename.equalsIgnoreCase("admin"))
            fm.createFolder();
        else
            System.out.println("Access Denied , only access by admin");
    }


    public void deleteFile() {
        if (rolename.equalsIgnoreCase("admin"))
            fm.deleteFile();
        else
            System.out.println("Access Denied , only access by admin");
    }

    
    public void deleteFolder() {
        if (rolename.equalsIgnoreCase("admin"))
            fm.deleteFolder();
        else
            System.out.println("Access Denied , only access by admin");
    }

    
    public void readFile() {
        if (rolename.equalsIgnoreCase("admin") || rolename.equalsIgnoreCase("user1"))
            fm.readFile();
        else
            System.out.println("Access Denied , only access by admin and user1");
    }

    
    public void writeFile() {
        if (rolename.equalsIgnoreCase("admin") || rolename.equalsIgnoreCase("user1"))
            fm.writeFile();
        else
            System.out.println("Access Denied , only access by admin and user1");
    }
}
