package CommonFileManager;
import DecoratorFileManager.*;
import ProxyFileManager.ProxyComponent;
import ProxyInheritaceFileManager.ProxyInheritance;
public class Main {
    public static void main(String[] args) {
        
        //Decorator
        System.out.println("Decorator -------------------------------");
        iFileManager fm=new DecoratorComponet(new FileManager(),"admin");
        fm.createFolder();
        fm.createFile();
        fm.writeFile();
        fm.deleteFolder();

        System.out.println("Proxy -------------------------------");
        //proxy
        fm=new ProxyComponent("admin");
        fm.createFile();
        fm.readFile();
        fm=new ProxyComponent("user1");
        fm.createFile();
        fm.deleteFile();
        fm.readFile();

        System.out.println("ProxyInheritance --------------------------------------");
        //proxyinheritance
        fm=new ProxyInheritance("user1");
        fm.createFile();
        fm.createFolder();
        fm.writeFile();
        fm.readFile();
    }
}
