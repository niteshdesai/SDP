package ProxyInheritaceFileManager;
import CommonFileManager.FileManager;

public class ProxyInheritance extends FileManager{
    String rolename;
   public ProxyInheritance(String role)
    {
       this.rolename=role;
    }

    public void createFile() {
        if (rolename.equalsIgnoreCase("admin"))
            super.createFile();
        else
            System.out.println("Access Denied , only access by admin");
    }


    public void createFolder() {
        if (rolename.equalsIgnoreCase("admin"))
            super.createFolder();
        else
            System.out.println("Access Denied , only access by admin");
    }


    public void deleteFile() {
        if (rolename.equalsIgnoreCase("admin"))
            super.deleteFile();
        else
            System.out.println("Access Denied , only access by admin");
    }

    
    public void deleteFolder() {
        if (rolename.equalsIgnoreCase("admin"))
            super.deleteFolder();
        else
            System.out.println("Access Denied , only access by admin");
    }

    
    public void readFile() {
        if (rolename.equalsIgnoreCase("admin") || rolename.equalsIgnoreCase("user1"))
            super.readFile();
        else
            System.out.println("Access Denied , only access by admin and user1");
    }

    
    public void writeFile() {
        if (rolename.equalsIgnoreCase("admin") || rolename.equalsIgnoreCase("user1"))
            super.writeFile();
        else
            System.out.println("Access Denied , only access by admin and user1");
    }
}
