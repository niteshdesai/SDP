public interface desserts
{
    public void prepar();
}