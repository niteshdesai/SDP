public class indianMain implements maincourse{
    public void prepar()
    {
        System.out.println("Indian Main Course. ");
    }
}
