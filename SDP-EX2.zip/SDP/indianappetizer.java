public class indianappetizer implements appetizers{
    public void prepar()
    {
        System.out.println("Indian Appetizers");
    }
}
