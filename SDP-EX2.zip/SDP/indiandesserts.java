public class indiandesserts implements desserts{
    public void prepar()
    {
        System.out.println("Indian Desserts. ");
    }
}
