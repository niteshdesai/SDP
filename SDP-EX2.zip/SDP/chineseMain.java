public class chineseMain implements maincourse{
    public void prepar()
    {
        System.out.println("Chinese Main Course");
    }
}
