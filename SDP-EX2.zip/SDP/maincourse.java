public interface maincourse {
    public void prepar();
}
