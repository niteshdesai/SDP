
public interface waterTax  {
    public String gettax();
}
