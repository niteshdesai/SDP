import java.util.*;
public class Main {
    public static void main(String[] args) {

       Scanner sc=new Scanner(System.in);
      
       System.out.println("Enter Tax Type");
       String type= sc.next().toLowerCase();

       if(type.equalsIgnoreCase("water"))
       {
        waterTax obj=null;
        System.out.println("Enter Your MC Area:");
        String area= sc.next().toLowerCase();
        obj=Factory1.gettaxobj(area);
         System.out.println(obj.gettax());
       }
       else if(type.equalsIgnoreCase("proparty"))
       {
         propartytax obj1=null;
         System.out.println("Enter Your MC Area:");
        String area= sc.next().toLowerCase();
        obj1=Factory2.gettaxobj(area);
         System.out.println(obj1.getprotax());
       }
    }
}
