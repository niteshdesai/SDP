public interface propartytax {
    public String getprotax();
}
