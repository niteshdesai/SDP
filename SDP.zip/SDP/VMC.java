public class VMC implements waterTax,propartytax {
    public String gettax()
    {
        return "Tax By VMC";
    }
    public String getprotax()
    {
        return "Tax of pro By AMC";
    }
}
