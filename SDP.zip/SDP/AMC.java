public class AMC implements waterTax,propartytax {
    
    public String gettax()
    {
        return "Tax By AMC";
    }
    public String getprotax()
    {
        return "Tax of pro By AMC";
    }
}
