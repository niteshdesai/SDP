public class SMC implements waterTax,propartytax {
    public String gettax()
    {
        return "Tax By SMC";
    }
    public String getprotax()
    {
        return "Tax of pro By AMC";
    }
}
