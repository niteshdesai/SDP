public class Factory2 {
    public static propartytax gettaxobj(String area)
    {
        propartytax obj=null;
        
         
        if(area.equalsIgnoreCase("AMC"))
        {
             obj=new AMC();
        }
        else if (area.equalsIgnoreCase("VMC")) {
            obj=new VMC();
        }
        else if (area.equalsIgnoreCase("SMC")) {
            obj=new SMC();
        }
        else
        {
            throw new IllegalAccessError();
        }
        
        return obj;

    }
}

