public class Factory1 {
    public static waterTax gettaxobj(String area)
    {
        waterTax obj=null;
        
         
        if(area.equalsIgnoreCase("AMC"))
        {
             obj=new AMC();
        }
        else if (area.equalsIgnoreCase("VMC")) {
            obj=new VMC();
        }
        else if (area.equalsIgnoreCase("SMC")) {
            obj=new SMC();
        }
        else
        {
            throw new IllegalAccessError();
        }
        
        return obj;

    }
}
