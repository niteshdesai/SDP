public class Main {
    public static void main(String[] args) {
        StringDirector Director = new StringDirector();
        stringBuilder builder = new plainString();

        
         content formalString = Director.createFormalString(
            builder, "milan", "I hope this message finds you well."
        );
        System.out.println("Formal Greeting:\n" + formalString);

        
        builder = new plainString();

        
         content casualString= Director.createCasualString(
            builder, "nitesh", "How’s it going?"
        );
        System.out.println("\nCasual Greeting:\n" + casualString);
    }
}