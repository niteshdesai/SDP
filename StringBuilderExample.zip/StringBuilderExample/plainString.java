class plainString implements stringBuilder {
    private StringBuilder buffer = new StringBuilder();

    @Override
    public void buildSalutation(String salutation) {
        buffer.append(salutation).append(", ");
    }

    @Override
    public void buildRecipient(String recipient) {
        buffer.append(recipient).append("!\n");
    }

    @Override
    public void buildBody(String body) {
        buffer.append(body).append("\n");
    }

    @Override
    public void buildClosing(String closing) {
        buffer.append(closing);
    }

    @Override
    public content getResult() {
        return new content(buffer.toString());
    }
}
