class StringDirector {
    public content createFormalString(stringBuilder builder, String recipient, String body) {
        builder.buildSalutation("Dear");
        builder.buildRecipient(recipient);
        builder.buildBody(body);
        builder.buildClosing("Sincerely,\n nitesh Desai");
        return builder.getResult();
    }

    public content createCasualString(stringBuilder builder, String recipient, String body) {
        builder.buildSalutation("Hey");
        builder.buildRecipient(recipient);
        builder.buildBody(body);
        builder.buildClosing("Cheers,\n milan");
        return builder.getResult();
    }
}
