class content {
    private String content;

    public content(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return content;
    }
}