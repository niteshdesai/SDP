interface stringBuilder {
    void buildSalutation(String salutation);
    void buildRecipient(String recipient);
    void buildBody(String body);
    void buildClosing(String closing);
    content getResult();
}