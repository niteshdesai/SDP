import java.io.*;


public class DecoratorPattern {
    public static void main(String[] args) {
        try {
       
            InputStreamDecorator inputStream = new InputStreamDecorator(new FileInputStream("input.txt"));
            while (inputStream.read() != -1);
            System.out.println("Character :"+inputStream.characterCount());
            System.out.println("Word :"+inputStream.wordCount());
            System.out.println("Line :"+inputStream.lineCount());
            inputStream.close();

            OutputStream outputStream = new OutputStreamDecorator(new FileOutputStream("output.txt"));
            outputStream.write("Sample Output Data".getBytes());
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
