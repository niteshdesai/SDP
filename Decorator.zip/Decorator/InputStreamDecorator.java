import java.io.IOException;
import java.io.InputStream;

public class InputStreamDecorator extends InputStream{
     private final InputStream wrapped;
    private int charCount = 0, wordCount = 0, lineCount = 0;
    private boolean inWord = false;

    public InputStreamDecorator(InputStream wrapped) {
             this.wrapped = wrapped;
    }

    @Override
    public int read() throws IOException {
        int byteData = wrapped.read();
        if (byteData == -1) {
            printStatistics();
            return -1;
        }
        char ch = (char) byteData;
        charCount++;
        if (ch == '\n') lineCount++;
        
        if (Character.isWhitespace(ch)) {
            inWord = false;
        } else if (!inWord) {
            wordCount++;
            inWord = true;
        }
        
        System.out.println("Read byte: " + byteData);
        return byteData;
    }

    private void printStatistics() {
        System.out.println("Characters read: " + charCount);
        System.out.println("Words read: " + wordCount);
        System.out.println("Lines read: " + lineCount);
    }

    @Override
    public void close() throws IOException {
        wrapped.close();
    }
}
