import java.io.*;


public class DecoratorPattern {
    public static void main(String[] args) {
        try {
       
            InputStream inputStream = new InputStreamDecorator(new FileInputStream("input.txt"));
            while (inputStream.read() != -1);
     
            inputStream.close();

            OutputStream outputStream = new OutputStreamDecorator(new FileOutputStream("output.txt"));
            outputStream.write("Sample Output Data".getBytes());
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
