public class invoice_wfwoh  implements invoice
{
    String itype="";

    invoice_wfwoh()
    {
        itype="woall";
    }

    public String getinvoice()
    {
        return itype;
    }
}
