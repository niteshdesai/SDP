import java.util.*;
public class Factory {
    public static invoice gettype()
    {
        invoice obj=null;
        
        Scanner st=new Scanner(System.in);
            
       while(true)
       {
         System.out.println("1:invoice_wall");
         System.out.println("2:invoice_woall");
         System.out.println("3:invoice_wh");
         System.out.println("4:invoice_wf");
         System.out.println("5:invoice_whwof");
         System.out.println("6:invoice_wfwoh");
         System.out.println("Enter your choice:");
         int choice=st.nextInt();
        switch (choice) {
            case 1:obj =new invoice_wall();
                   break;
            case 2:obj =new invoice_woall();
                   break;
            case 3:obj =new invoice_wh();
                   break;
            case 4:obj =new invoice_wf();
                   break;
            case 5:obj =new invoice_whwof();
                   break;
            case 6:obj =new invoice_wfwoh();
                   break;
            
            default:
                break;
        }
        return obj;

    }

        
    }
}
