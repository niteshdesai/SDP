public class invoice_woall implements invoice
{
    String itype="";

    invoice_woall()
    {
        itype="woall";
    }

    public String getinvoice()
    {
        return itype;
    }
} 
