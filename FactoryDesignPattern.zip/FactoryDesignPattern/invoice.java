public interface invoice {
    public String getinvoice();
}
