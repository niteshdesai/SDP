public class invoice_wall implements invoice
{
    String itype="";

    invoice_wall()
    {
        itype="wall";
    }

    public String getinvoice()
    {
        return itype;
    }
} 