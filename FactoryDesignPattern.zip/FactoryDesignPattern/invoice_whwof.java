public class invoice_whwof  implements invoice

{
    String itype="";

    invoice_whwof()
    {
        itype="whwof";
    }

    public String getinvoice()
    {
        return itype;
    }
}
