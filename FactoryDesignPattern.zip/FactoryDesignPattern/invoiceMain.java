public class invoiceMain {
    public static void main(String[] args) {
        invoice obj=Factory.gettype();
        System.out.println(obj.getinvoice());
    }
}
