public class windowbtn implements button{
    public void createButton()
    {
        System.out.println("Button of window");
    }
    
}
