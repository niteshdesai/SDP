public class linuxrbtn implements radiobutton{
    public void createRadio()
    {
        System.out.println("RadioButton of linux");
    }
}
