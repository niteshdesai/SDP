public class windowchk implements checkBox{
    public void createCheckbox()
    {
        System.out.println("checkBox of window");
    }
    
}
