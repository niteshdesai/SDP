public interface button {
     public void createButton();
}