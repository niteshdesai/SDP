public class macFactory extends abstractFactory{
    public  button getBtn()
    {
        return new macbtn();
    }
    public  radiobutton getRbtn()
    {
        return new macrbtn();
    }
    public checkBox getchk()
    {
        return new macchk();
    }
}
