public class macchk implements checkBox{
    public void createCheckbox()
    {
        System.out.println("CheckBox  of Mac");
    }
}
