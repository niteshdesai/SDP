public interface radiobutton {
    public void createRadio();
}
