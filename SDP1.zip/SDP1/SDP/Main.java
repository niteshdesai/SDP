import java.util.*;
public class Main {
    public static void main(String[] args) {
         Scanner sc=new Scanner(System.in);
        System.out.println("Enter your os");
        String os=sc.next();

        abstractFactory obj=abstractFactory.getComponet(os);
        button btn=obj.getBtn();

        btn.createButton();
       

    }
}
