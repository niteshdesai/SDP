public class btnFactory implements abstractFactory {
    button obj = null;

    public button getbutton(String os) {
        if (os == "window") {
            obj = new windowbtn();
        } else if (os == "mac") {
            obj = new macbtn();
        }
        else
        {
            obj=new linuxbtn();
        }
        return obj;
    }
    public radiobutton getradiobutton(String os)
    {
        return null;
    }
     public checkBox getcheckBox(String os)
     {
        return null;
     }

}
