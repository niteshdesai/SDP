public class windowFactory {
    public static button getBtn()
    {
        return new windowbtn();
    }
    public static radiobutton getRbtn()
    {
        return new windowrbtn();
    }
    public static checkBox getchk()
    {
        return new windowchk();
    }
}
