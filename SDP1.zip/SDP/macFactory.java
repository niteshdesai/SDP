public class macFactory {
    public static button getBtn()
    {
        return new macbtn();
    }
    public static radiobutton getRbtn()
    {
        return new macrbtn();
    }
    public static checkBox getchk()
    {
        return new macchk();
    }
}
