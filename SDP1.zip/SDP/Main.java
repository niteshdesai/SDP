import java.util.*;
public class Main {
    public static void main(String[] args) {
         Scanner sc=new Scanner(System.in);
        System.out.println("Enter your Componet");

        abstractFactory btn=createFactory.getf("radiobutton");
        button b=btn.getbutton("linux");
        b.createButton();

    }
}
