public class linuxFactory {
    public static button getBtn()
    {
        return new linuxbtn();
    }
    public static radiobutton getRbtn()
    {
        return new linuxrbtn();
    }
    public static checkBox getchk()
    {
        return new linuxchk();
    }
}
