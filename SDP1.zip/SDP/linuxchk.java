public class linuxchk implements checkBox {
    public void createCheckbox()
    {
        System.out.println("CheckBox  of linux");
    }
}
