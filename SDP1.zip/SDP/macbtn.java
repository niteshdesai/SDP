public class macbtn implements button  {
    public void createButton()
    {
        System.out.println("Button of Mac");
    }
 
}
