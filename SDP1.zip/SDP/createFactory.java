public class createFactory {
    
    public static abstractFactory getf(String componet)
    {
          if(componet.equalsIgnoreCase("Button"))
          {
            return new btnFactory();
          }
          else if(componet.equalsIgnoreCase("RadioButton"))
          {
            return new radioFactory();
          }
          else
          {
            return new checkboxFactory();
          }
    }
}
