public class checkboxFactory implements abstractFactory{
   checkBox obj=null;
    public button getbutton(String os) {
    
        return null;
    }
    public radiobutton getradiobutton(String os)
    {
        return null;
    }
     public checkBox getcheckBox(String os)
     {
        if (os == "window") {
            obj = new windowchk();
        } else if (os == "mac") {
            obj = new macchk();
        }
        else
        {
            obj=new linuxchk();
        }
        return obj;
     }
}
