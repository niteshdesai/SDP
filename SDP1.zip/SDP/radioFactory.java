public class radioFactory  implements abstractFactory{
    radiobutton obj=null;
    public button getbutton(String os) {
      
        return null;
    }
    public radiobutton getradiobutton(String os)
    {
        if (os == "window") {
            obj = new windowrbtn();
        } else if (os == "mac") {
            obj = new macrbtn();
        }
        else
        {
            obj=new linuxrbtn();
        }
        return obj;
    }
     public checkBox getcheckBox(String os)
     {
        return null;
     }
}
