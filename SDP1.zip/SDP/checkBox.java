public interface checkBox {
   public void createCheckbox();
}