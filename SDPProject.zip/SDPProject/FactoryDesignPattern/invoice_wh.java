public class invoice_wh implements invoice
{
    String itype="";

    invoice_wh()
    {
        itype="wh";
    }

    public String getinvoice()
    {
        return itype;
    } 
}
