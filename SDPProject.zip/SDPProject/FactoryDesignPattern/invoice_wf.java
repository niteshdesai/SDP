public class invoice_wf implements invoice
 {
    String itype="";

    invoice_wf()
    {
        itype="wf";
    }

    public String getinvoice()
    {
        return itype;
    }
}
