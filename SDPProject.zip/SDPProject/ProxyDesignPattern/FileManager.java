
public class FileManager implements iFileManager{

    @Override
    public void createFolder() {
       System.out.println("Create Folder");  
    }
    @Override
    public void deleteFolder() {
       System.out.println("Delete Folder");
    }
    @Override
    public void createFile() {
       System.out.println("Create File");
    }
    @Override
    public void deleteFile() {
        System.out.println("Delete File");
    }
    @Override
    public void readFile() {
        System.out.println("Read File");
    }
    @Override
    public void writeFile() {
       System.out.println("Write File");
    }
}
