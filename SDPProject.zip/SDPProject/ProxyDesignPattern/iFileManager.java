public interface iFileManager {
    public void createFolder();
    public void deleteFolder();
    public void createFile();
    public void deleteFile();
    public void readFile();
    public void writeFile();
}
