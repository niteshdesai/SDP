
public class Main {
    public static void main(String[] args) {
        iFileManager fm;
        System.out.println("Proxy -------------------------------");
        //proxy
        fm=new ProxyFileManager("admin");
        fm.createFile();
        fm.readFile();
        fm=new ProxyFileManager("user1");
        fm.createFile();
        fm.deleteFile();
        fm.readFile();

     
    }
}
