public interface appetizers {

    public void prepar();
}
