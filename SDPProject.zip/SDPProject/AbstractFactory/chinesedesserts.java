public class chinesedesserts implements desserts{
    public void prepar()
    {
        System.out.println("chinese Desserts");
    }
}
