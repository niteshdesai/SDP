public class chineseappetizers implements appetizers{
    public void prepar()
    {
        System.out.println("Chinese Appetizers");
    }
}
