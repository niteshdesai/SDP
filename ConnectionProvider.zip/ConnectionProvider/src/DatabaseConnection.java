

import java.sql.*;
public interface DatabaseConnection {
    public Connection connect();
    public void disconnect();
} 
